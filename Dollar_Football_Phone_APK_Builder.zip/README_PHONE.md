# Build DOLLAR FOOTBALL APK using only your phone

1. Create/sign in to a GitHub account.
2. Create a new repository named `dollar-football`.
3. Upload ALL files and folders from this project ZIP to the repository.
4. Make sure `.github/workflows/build-apk.yml` is uploaded too.
5. Open the repository's **Actions** tab.
6. Select **Build DOLLAR FOOTBALL APK**.
7. Tap **Run workflow** (if it has not already started).
8. Wait for the green check/completed run.
9. Open the completed run and find **Artifacts**.
10. Download `Dollar-Football-APK`.
11. Extract it and install `app-debug.apk` on your Android phone.

GitHub Actions runs the Android build on a hosted runner, so your phone does not need Android Studio.
