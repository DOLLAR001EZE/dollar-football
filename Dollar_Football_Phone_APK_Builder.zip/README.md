# DOLLAR FOOTBALL — Android Project

This project wraps the latest DOLLAR FOOTBALL mobile prototype in a native Android WebView.

## Build an APK in Android Studio
1. Install Android Studio.
2. Open this folder: `Dollar_Football_Android_Project`.
3. Let Android Studio download the Android SDK/Gradle components it requests.
4. Select **Build → Build APK(s)**.
5. The debug APK will be created under:
   `app/build/outputs/apk/debug/app-debug.apk`

The current game is still a prototype. The Android wrapper makes it installable, but it does not yet provide production-level 3D graphics, online multiplayer, or a Play Store release package.
